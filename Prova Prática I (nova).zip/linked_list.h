//! Aluno(a): <Coloque seu nome aqui>
#ifndef STRUCTURES_LINKED_LIST_H
#define STRUCTURES_LINKED_LIST_H

#include <cstddef>  // std::size_t
#include <stdexcept>  // C++ exceptions


namespace structures {

//! Classe Lista Encadeada
template<typename T>
class LinkedList {
 public:
    LinkedList();  // construtor padrão
    ~LinkedList();  // destrutor
    void clear();  // limpar lista
    void push_back(const T& data);  // inserir no fim
    void push_front(const T& data);  // inserir no início
    void insert(const T& data, std::size_t index);  // inserir na posição
    void insert_sorted(const T& data);  // inserir em ordem
    T& at(std::size_t index);  // acessar um elemento na posição index
    T pop(std::size_t index);  // retirar da posição
    T pop_back();  // retirar do fim
    T pop_front();  // retirar do início
    void remove(const T& data);  // remover específico
    bool empty() const;  // lista vazia
    bool contains(const T& data) const;  // contém
    std::size_t find(const T& data) const;  // posição do dado
    std::size_t size() const;  // tamanho da lista

    // PROVA: implemente somente os cinco métodos abaixo.
    // Não copie/atribua objetos LinkedList: a classe não possui cópia profunda.
    void rotate_left(std::size_t k);
    std::size_t compress_runs();
    void erase_range(std::size_t first, std::size_t last);
    void interleave(LinkedList<T>* other);
    std::size_t stable_partition(const T& pivot);

 private:
    class Node {  // Elemento
     public:
        //! Construtor usando apenas o dado.
        explicit Node(const T& data):
        data_{data}
        {}

        //! Construtor de um nodo completo.
        explicit Node(const T& data, Node* next):
        data_{data},
        next_{next}
        {}

        //! Retorna o dado armazenado.
        T& data() {
            return data_;
        }

        //! Retorna o dado armazenado.
        const T& data() const {
            return data_;
        }

        //! Retorna ponteiro para próximo nodo.
        Node* next() {  // getter: próximo
            return next_;
        }

        //! Retorna ponteiro para o o próximo node.
        const Node* next() const {  // getter const: próximo
            return next_;
        }

        //! Altera o ponteiro para o próximo.
        void next(Node* node) {  // setter: próximo
            next_ = node;
        }

     private:
        T data_;  // data_
        Node* next_{nullptr};  // next_
    };

    //! Passa pelos nós até o último.
    Node* end() {  // último nó da lista
        auto it = head;
        for (auto i = 1u; i < size(); ++i) {
            it = it->next();
        }
        return it;
    }

    //! Passa pelos nós até o anterior ao índice procurado.
    Node* before_index(std::size_t index) {  // nó anterior ao index
        auto it = head;
        for (auto i = 1u; i < index; ++i) {
            it = it->next();
        }
        return it;
    }

    void insert(const T& data, Node* before);  // inserir na posição polimórfico

    Node* head{nullptr};  // head
    std::size_t size_{0u};  // size_
};

}  // namespace structures


// PROVA: consulte enunciados, exemplos e exceções no enunciado.
template<typename T>
void structures::LinkedList<T>::rotate_left(std::size_t k) {
    (void) k;
    // TODO: implementar.
}

template<typename T>
std::size_t structures::LinkedList<T>::compress_runs() {
    // TODO: implementar.
    return 0u;
}

template<typename T>
void structures::LinkedList<T>::erase_range(std::size_t first, std::size_t last) {
    (void) first;
    (void) last;
    // TODO: implementar.
}

template<typename T>
void structures::LinkedList<T>::interleave(LinkedList<T>* other) {
    (void) other;
    // TODO: implementar.
}

template<typename T>
std::size_t structures::LinkedList<T>::stable_partition(const T& pivot) {
    (void) pivot;
    // TODO: implementar.
    return 0u;
}

//! Construtor padrão
template<typename T>
structures::LinkedList<T>::LinkedList() {}

//! Destrutor
template<typename T>
structures::LinkedList<T>::~LinkedList() {
    clear();
}

//! Esvazia a lista.
template<typename T>
void structures::LinkedList<T>::clear() {
    while (!empty())
        pop_front();
}

//! Inserção no fim da lista.
template<typename T>
void structures::LinkedList<T>::push_back(const T& data) {
    insert(data, size_);
}

//! Inserção no começo da lista.
template<typename T>
void structures::LinkedList<T>::push_front(const T& data) {
    Node* new_node = new Node(data);
    if (new_node == nullptr)
        throw std::out_of_range("Full list!");

    new_node->next(head);
    head = new_node;
    size_++;
}

//! Inserção em qualquer posição da lista.
template<typename T>
void structures::LinkedList<T>::insert(const T& data, std::size_t index) {
    if (index > size_)
        throw std::out_of_range("Invalid index!");

    if (index == 0) {
        push_front(data);
    } else {
        Node* new_node = new Node(data);
        if (new_node == nullptr)
            throw std::out_of_range("Full list!");

        Node* before = before_index(index);
        Node* next = before->next();
        new_node->next(next);
        before->next(new_node);
        size_++;
    }
}

//! Inserção em qualquer posição da lista recebendo um ponteiro para um Node.
template<typename T>
void structures::LinkedList<T>::insert(const T& data, Node* before) {
    Node* new_node = new Node(data);
    if (new_node == nullptr)
        throw std::out_of_range("Full list!");

    new_node->next(before->next());
    before->next(new_node);
    size_++;
}

//! Inserção ordenada na lista.
template<typename T>
void structures::LinkedList<T>::insert_sorted(const T& data) {
    if (empty()) {
        push_front(data);
    } else {
        Node* current = head;
        Node* before = head;
        std::size_t position = size();
        for (auto i = 0u; i < size(); ++i) {
            if (!(data > current->data())) {
                position = i;
                break;
            }
            before = current;
            current = current->next();
        }
        position == 0? push_front(data) : insert(data, before);
    }
}

//! Coleta o dado na posição da lista.
template<typename T>
T& structures::LinkedList<T>::at(std::size_t index) {
    if (index >= size())
        throw std::out_of_range("Invalid index or empty list!");

    Node* current = index == 0? head : before_index(index)->next();
    return current->data();
}

//! Coleta o dado de uma posição específica, removendo-o da lista.
template<typename T>
T structures::LinkedList<T>::pop(std::size_t index) {
    if (empty())
        throw std::out_of_range("Empty list");
    if (index >= size())
        throw std::out_of_range("Invalid index!");

    if (index == 0)
        return pop_front();

    Node* before_out = before_index(index);
    Node* out = before_out->next();
    T data = out->data();
    before_out->next(out->next());
    size_--;
    delete out;
    return data;
}

//! Coleta o dado do final, removendo-o da lista
template<typename T>
T structures::LinkedList<T>::pop_back() {
    return pop(size_ - 1u);
}

//! Coleta o dado do início, removendo-o da lista
template<typename T>
T structures::LinkedList<T>::pop_front() {
    if (empty())
        throw std::out_of_range("Empty list!");

    auto out = head;
    T data = out->data();
    head = out->next();
    size_--;
    delete out;
    return data;
}

//! Remoção de um dado da lista.
template<typename T>
void structures::LinkedList<T>::remove(const T& data) {
    pop(find(data));
}

//! Testa se a lista está vazia.
template<typename T>
bool structures::LinkedList<T>::empty() const {
    return size() == 0u;
}

//! Testa se um dado está na lista.
template<typename T>
bool structures::LinkedList<T>::contains(const T& data) const {
    return find(data) != size();
}

//! Procura o índice do dado; se não encontrar, retorna o tamanho da lista.
template<typename T>
std::size_t structures::LinkedList<T>::find(const T& data) const {
    std::size_t index = 0u;
    Node* current = head;
    while (index < size()) {
        if (current->data() == data)
            break;
        current = current->next();
        index++;
    }
    return index;
}

//! Retorna o tamanho da lista.
template<typename T>
std::size_t structures::LinkedList<T>::size() const {
    return size_;
}

#endif  // STRUCTURES_LINKED_LIST_H
